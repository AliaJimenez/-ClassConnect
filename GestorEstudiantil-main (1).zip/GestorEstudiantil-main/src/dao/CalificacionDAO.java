package dao;

import Modelos.Calificacion;
import Modelos.conexionlocal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CalificacionDAO {
    
    // Obtener calificaciones por estudiante
    public List<Calificacion> obtenerPorEstudiante(int idEstudiante) {
        List<Calificacion> lista = new ArrayList<>();
        
        String sql = "SELECT asig.nombre_asignatura, n.calificacion, n.periodo, n.observacion " +
                     "FROM notas n " +
                     "INNER JOIN asignaturas asig ON n.id_asignatura = asig.id_asignatura " +
                     "WHERE n.id_estudiante = ?";
        
        try {
            Connection con = conexionlocal.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idEstudiante);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String obs = rs.getString("observacion");
                if (obs == null) obs = "";

                lista.add(new Calificacion(
                        rs.getString("nombre_asignatura"),
                        rs.getDouble("calificacion"),
                        rs.getString("periodo"),
                        obs
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }
    
    
    // Calcular promedio por estudiante (opcional por periodo)
    public double obtenerPromedio(int idEstudiante, String periodo) {
        double prom = 0.0;
        
        String sql = "SELECT AVG(calificacion) AS promedio FROM notas WHERE id_estudiante = ?";
        if (periodo != null) sql += " AND periodo = ?";
        
        try {
            Connection con = conexionlocal.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idEstudiante);
            if (periodo != null) ps.setString(2, periodo);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) prom = rs.getDouble("promedio");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return prom;
    }
    
    
    // Obtener mejor materia (mayor promedio)
    public Calificacion obtenerMejorMateria(int idEstudiante, String periodo) throws Exception {
        
        String sql = "SELECT asig.nombre_asignatura, AVG(n.calificacion) AS promedio " +
                     "FROM notas n " +
                     "INNER JOIN asignaturas asig ON n.id_asignatura = asig.id_asignatura " +
                     "WHERE n.id_estudiante = ?" +
                     (periodo != null ? " AND n.periodo = ?" : "") +
                     " GROUP BY asig.nombre_asignatura " +
                     "ORDER BY promedio DESC LIMIT 1";
        
        try (Connection con = conexionlocal.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, idEstudiante);
            if (periodo != null) ps.setString(2, periodo);
            
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String obs = null;
                Calificacion cal = new Calificacion(rs.getString("nombre_asignatura"), rs.getDouble("calificacion"), rs.getString("periodo"), obs);
                cal.setNombreAsignatura(rs.getString("nombre_asignatura"));
                cal.setCalificacion(rs.getDouble("promedio"));
                return cal;
            }
        }
        
        return null;
    }
    
    
    // Obtener peor materia (menor promedio)
    public Calificacion obtenerPeorMateria(int idEstudiante, String periodo) throws Exception {
        
        String sql = "SELECT asig.nombre_asignatura, AVG(n.calificacion) AS promedio " +
                     "FROM notas n " +
                     "INNER JOIN asignaturas asig ON n.id_asignatura = asig.id_asignatura " +
                     "WHERE n.id_estudiante = ?" +
                     (periodo != null ? " AND n.periodo = ?" : "") +
                     " GROUP BY asig.nombre_asignatura " +
                     "ORDER BY promedio ASC LIMIT 1";
        
        try (Connection con = conexionlocal.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, idEstudiante);
            if (periodo != null) ps.setString(2, periodo);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String obs = null;
                var cal = new Calificacion(rs.getString("nombre_asignatura"), rs.getDouble("calificacion"), rs.getString("periodo"), obs);
                cal.setNombreAsignatura(rs.getString("nombre_asignatura"));
                cal.setCalificacion(rs.getDouble("promedio"));
                return cal;
            }
        }
        
        return null;
    }
}
