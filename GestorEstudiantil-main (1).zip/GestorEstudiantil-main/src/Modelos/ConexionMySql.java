/*
Paquete de modelos para el Back end y la conexion a base de datos.
*/
package Modelos;

import java.sql;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

/**
 *
 
@author mikew*/
public class ConexionMySql {



    Connection Connect = null;
    String url = "jdbc:mysql://avnadmin:AVNS_h0gAu_qAYr-EcMGrp0W@mysql-321a6a22-mikewadamesherrera-7106.k.aivencloud.com:23184/sistema_escolar?ssl-mode=REQUIRED";
    String user = "avnadmin";
    String pass = "AVNS_h0gAu_qAYr-EcMGrp0W";

    public Connection conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.driver");
            Connect = DriverManager.getConnection(url,user,pass);
            System.out.println("Estamos conectados con exito!");

        } catch (ClassNotFoundException | SQLException sqlex) {
            System.out.println("Error al tratar de conectar: " + sqlex);
        }
        return Connect;
    }


}