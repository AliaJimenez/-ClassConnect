/*
Paquete de modelos para el Back end y la conexion a base de datos.
*/
package Modelos;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

/**
 *
 * @author mikew
 */
public class ConexionMySql {
    
    Connection Connect = null;
       
    public Connection conectar() {
        try {
            Class.forName("");
            Connect = DriverManager.getConnection("");
            System.out.println("Estamos conectados con exito!");

        } catch (ClassNotFoundException | SQLException sqlex) {
            System.out.println("Error al tratar de conectar: " + sqlex);
        }
        return Connect;
    }
    
    
}
